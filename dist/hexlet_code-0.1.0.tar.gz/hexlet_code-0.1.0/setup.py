# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer']

package_data = \
{'': ['*'], 'page_analyzer': ['templates/*']}

install_requires = \
['flask>=2.3.2,<3.0.0',
 'gunicorn==20.1.0',
 'psycopg2-binary>=2.9.6,<3.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'validators>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Third project performed as part of the Hexlet Python Course',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ggByron/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/ggByron/python-project-83/actions)\n\n<a href="https://codeclimate.com/github/ggByron/python-project-83/maintainability"><img src="https://api.codeclimate.com/v1/badges/13abae70d676a80a1864/maintainability" /></a>\n\n[Ссылка на проект](https://python-project-83-production-7aae.up.railway.app/)\n',
    'author': 'ggByron',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>3.8.1',
}


setup(**setup_kwargs)
